"""Use Faster Whisper directly; avoid loading Buzz's unused GUI/API/plugin stack."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import subprocess


def emit(kind, **fields):
    print('STUDIO_EVENT '+json.dumps({'kind':kind,**fields},ensure_ascii=False),flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['add'])
    parser.add_argument('--model-type',default='fasterwhisper')
    parser.add_argument('--model-size',default='small')
    parser.add_argument('--language',default=None)
    parser.add_argument('--txt',action='store_true')
    parser.add_argument('--hide-gui',action='store_true')
    parser.add_argument('--output-directory',required=True)
    parser.add_argument('source')
    args=parser.parse_args()
    folder=Path(os.environ['STUDIO_JOB_DIR']).resolve()
    folder.mkdir(parents=True,exist_ok=True)
    os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
    os.environ['HF_HOME']=str(folder/'hf')
    os.environ['TEMP']=os.environ['TMP']=str(folder)
    source=args.source
    title=Path(source).stem
    try:
        try:
            import truststore
            truststore.inject_into_ssl()
        except ImportError:
            pass
        if source.startswith(('https://','http://')):
            from core import normalize_youtube_url
            source,_=normalize_youtube_url(source)
            emit('stage',stage='downloading',message='Downloading the video audio')
            from yt_dlp import YoutubeDL
            class Logger:
                def debug(self,msg): print(msg,flush=True)
                def info(self,msg): print(msg,flush=True)
                def warning(self,msg): print(msg,flush=True)
                def error(self,msg): print(msg,flush=True)
            def progress(data):
                total=data.get('total_bytes') or data.get('total_bytes_estimate')
                if total:
                    emit('progress',stage='downloading',fraction=min(1,data.get('downloaded_bytes',0)/total))
            with YoutubeDL({'format':'bestaudio/best','noplaylist':True,
                            'outtmpl':str(folder/'source.%(ext)s'),'logger':Logger(),
                            'progress_hooks':[progress]}) as ydl:
                info=ydl.extract_info(source,download=True)
                title=info.get('title') or 'YouTube transcript'
                downloads=info.get('requested_downloads') or []
                source=info.get('filepath') or (downloads[0].get('filepath') if downloads else None) or ydl.prepare_filename(info)
        emit('stage',stage='loading',message='Loading Faster Whisper / downloading the model if needed')
        # Buzz's setup normally loads CUDA DLL paths for this same engine.
        try:
            import buzz.cuda_setup  # noqa: F401
        except ImportError:
            pass
        from faster_whisper import WhisperModel, BatchedInferencePipeline
        cpu=os.environ.get('BUZZ_FORCE_CPU','false')!='false'
        model=WhisperModel(args.model_size,device='cpu' if cpu else 'auto',compute_type='default',
                           cpu_threads=max(1,(os.cpu_count() or 8)//2),
                           download_root=os.environ.get('BUZZ_MODEL_ROOT'),
                           local_files_only=os.environ.get('HF_HUB_OFFLINE')=='1')
        emit('progress',stage='transcribing',fraction=0)
        # Use the FFmpeg decoder, as Buzz does. This also avoids PyAV API drift
        # between the installed faster-whisper and av package versions.
        import numpy as np
        decoded=subprocess.run(['ffmpeg','-nostdin','-v','error','-i',str(source),
                                '-f','f32le','-ac','1','-ar','16000','pipe:1'],
                               stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                               creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        if decoded.returncode:
            raise RuntimeError('FFmpeg could not decode the audio: '+decoded.stderr.decode('utf-8',errors='replace'))
        audio=np.frombuffer(decoded.stdout,dtype=np.float32)
        if audio.size==0:
            raise RuntimeError('No audio samples were found.')
        segments,info=BatchedInferencePipeline(model).transcribe(
            audio,language=args.language,task='transcribe',temperature=0,
            no_speech_threshold=.4,batch_size=8)
        result=[]
        for item in segments:
            result.append({'start_ms':round(item.start*1000),'end_ms':round(item.end*1000),
                           'text':item.text.strip()})
            if info.duration:
                emit('progress',stage='transcribing',fraction=min(1,item.end/info.duration))
        pending=folder/'segments.pending'
        pending.write_text(json.dumps({'title':title,'segments':result},ensure_ascii=False),encoding='utf-8')
        pending.replace(folder/'segments.json')
        emit('segments_ready',count=len(result))
        return 0
    except Exception as exc:
        import traceback
        traceback.print_exc()
        emit('failure',message=str(exc))
        return 1


if __name__=='__main__':raise SystemExit(main())
