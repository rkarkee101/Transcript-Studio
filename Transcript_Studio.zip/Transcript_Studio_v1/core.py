"""Jobs, validated YouTube input, process lifecycle, and TXT export."""
from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent
MODEL_TYPES = {"fasterwhisper", "whisper", "whispercpp", "huggingface"}
MODEL_SIZES = {"tiny", "base", "small", "medium", "large"}
LANGUAGES = {
    "af":"Afrikaans", "am":"Amharic", "ar":"Arabic", "as":"Assamese", "az":"Azerbaijani",
    "ba":"Bashkir", "be":"Belarusian", "bg":"Bulgarian", "bn":"Bengali", "bo":"Tibetan",
    "br":"Breton", "bs":"Bosnian", "ca":"Catalan", "cs":"Czech", "cy":"Welsh", "da":"Danish",
    "de":"German", "el":"Greek", "en":"English", "es":"Spanish", "et":"Estonian", "eu":"Basque",
    "fa":"Persian", "fi":"Finnish", "fo":"Faroese", "fr":"French", "gl":"Galician", "gu":"Gujarati",
    "ha":"Hausa", "haw":"Hawaiian", "he":"Hebrew", "hi":"Hindi", "hr":"Croatian", "ht":"Haitian Creole",
    "hu":"Hungarian", "hy":"Armenian", "id":"Indonesian", "is":"Icelandic", "it":"Italian",
    "ja":"Japanese", "jw":"Javanese", "ka":"Georgian", "kk":"Kazakh", "km":"Khmer", "kn":"Kannada",
    "ko":"Korean", "la":"Latin", "lb":"Luxembourgish", "ln":"Lingala", "lo":"Lao", "lt":"Lithuanian",
    "lv":"Latvian", "mg":"Malagasy", "mi":"Maori", "mk":"Macedonian", "ml":"Malayalam", "mn":"Mongolian",
    "mr":"Marathi", "ms":"Malay", "mt":"Maltese", "my":"Myanmar", "ne":"Nepali", "nl":"Dutch",
    "nn":"Nynorsk", "no":"Norwegian", "oc":"Occitan", "pa":"Punjabi", "pl":"Polish", "ps":"Pashto",
    "pt":"Portuguese", "ro":"Romanian", "ru":"Russian", "sa":"Sanskrit", "sd":"Sindhi", "si":"Sinhala",
    "sk":"Slovak", "sl":"Slovenian", "sn":"Shona", "so":"Somali", "sq":"Albanian", "sr":"Serbian",
    "su":"Sundanese", "sv":"Swedish", "sw":"Swahili", "ta":"Tamil", "te":"Telugu", "tg":"Tajik",
    "th":"Thai", "tk":"Turkmen", "tl":"Tagalog", "tr":"Turkish", "tt":"Tatar", "uk":"Ukrainian",
    "ur":"Urdu", "uz":"Uzbek", "vi":"Vietnamese", "yi":"Yiddish", "yo":"Yoruba", "zh":"Chinese",
}


def user_home() -> Path:
    return Path(os.environ.get("TRANSCRIPT_STUDIO_HOME") or
                Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local")) / "TranscriptStudio")


def default_output() -> str:
    if os.name == "nt":
        import ctypes
        buf = ctypes.create_unicode_buffer(32768)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 5, None, 0, buf) == 0:
            return str(Path(buf.value) / "YouTubeTranscripts")
    return str(Path.home() / "Documents" / "YouTubeTranscripts")


def normalize_youtube_url(value: str) -> tuple[str, str]:
    if not isinstance(value, str) or len(value) > 4096:
        raise ValueError("Paste one YouTube video link.")
    parsed = urlsplit(value.strip())
    if parsed.scheme not in ("http", "https") or parsed.username or parsed.password:
        raise ValueError("Use a YouTube link beginning with https://.")
    if parsed.port not in (None, 80, 443):
        raise ValueError("Use a standard YouTube video link.")
    host = (parsed.hostname or "").lower()
    parts = parsed.path.strip("/").split("/")
    if host == "youtu.be" and len(parts) == 1:
        video_id = parts[0]
    elif host in ("youtube.com", "www.youtube.com", "m.youtube.com"):
        if parsed.path == "/watch":
            video_id = parse_qs(parsed.query).get("v", [""])[0]
        elif len(parts) == 2 and parts[0] in ("live", "shorts", "embed"):
            video_id = parts[1]
        else:
            video_id = ""
    else:
        raise ValueError("Paste a youtube.com or youtu.be video link.")
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", video_id):
        raise ValueError("This link does not contain a valid YouTube video ID.")
    return f"https://www.youtube.com/watch?v={video_id}", video_id


@dataclass(frozen=True)
class Options:
    url: str
    video_id: str
    model_type: str
    model_size: str
    language: str
    timestamps: bool
    spacing: int
    output_dir: str
    cpu_only: bool = False
    model_id: str = ""

    @classmethod
    def from_request(cls, body):
        url, video_id = normalize_youtube_url(body.get("url", ""))
        model_type = body.get("model_type", "fasterwhisper")
        model_size = body.get("model_size", "small")
        language = body.get("language", "en")
        if model_type not in MODEL_TYPES or model_size not in MODEL_SIZES:
            raise ValueError("Choose a supported model type and size.")
        if language and language not in LANGUAGES:
            raise ValueError("Choose a supported language or Auto-detect.")
        if type(body.get("timestamps", True)) is not bool or type(body.get("cpu_only", False)) is not bool:
            raise ValueError("Invalid checkbox value.")
        spacing = body.get("spacing", 30)
        if type(spacing) is not int or spacing not in (0, 30, 60):
            raise ValueError("Choose segment, 30-second, or 60-second timestamps.")
        path = body.get("output_dir", "").strip() or default_output()
        if not Path(path).is_absolute() or len(path) > 1000:
            raise ValueError("Enter a full output folder path.")
        model_id = body.get("model_id", "").strip()
        if model_type == "huggingface" and not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", model_id):
            raise ValueError("Enter a public Hugging Face speech model ID, such as openai/whisper-small.")
        return cls(url, video_id, model_type, model_size, language,
                   body.get("timestamps", True), spacing, str(Path(path).resolve()),
                   body.get("cpu_only", False), model_id)


def timestamp(milliseconds: int) -> str:
    seconds = max(0, int(milliseconds)) // 1000
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def render_transcript(payload, options: Options) -> str:
    title = re.sub(r"[\r\n]+", " ", str(payload.get("title", "YouTube transcript"))).strip()
    segments = payload.get("segments")
    if not isinstance(segments, list) or not segments:
        raise ValueError("No speech segments were returned. No transcript was saved.")
    clean = []
    last_start = -1
    for item in segments:
        start, end = item.get("start_ms"), item.get("end_ms")
        text = re.sub(r"\s+", " ", str(item.get("text", ""))).strip()
        if (type(start) not in (int, float) or type(end) not in (int, float) or
                not math.isfinite(start) or not math.isfinite(end) or start < 0 or end < start or start < last_start):
            raise ValueError("The transcription engine returned invalid timestamps.")
        last_start = start
        if text:
            clean.append((int(start), int(end), text))
    if not clean:
        raise ValueError("No readable speech was returned. No transcript was saved.")
    paragraphs = []
    group_start = None
    group_end = 0
    group = []
    for start, end, text in clean:
        should_break = group and ((options.timestamps and options.spacing == 0) or
                                 (options.timestamps and start - group_start >= options.spacing * 1000) or
                                 start - group_end >= 5000)
        if should_break:
            prefix = f"[{timestamp(group_start)}] " if options.timestamps else ""
            paragraphs.append(prefix + " ".join(group))
            group = []
        if not group:
            group_start = start
        group.append(text)
        group_end = end
    if group:
        prefix = f"[{timestamp(group_start)}] " if options.timestamps else ""
        paragraphs.append(prefix + " ".join(group))
    model = options.model_id if options.model_type == "huggingface" else options.model_size
    header = [title, "=" * min(80, max(12, len(title))), f"Source: {options.url}",
              f"Created: {datetime.now().astimezone().isoformat(timespec='seconds')}",
              f"Model: {options.model_type} / {model}",
              f"Language: {LANGUAGES.get(options.language, 'Auto-detect')}",
              "Machine-generated transcript. Check names, numbers, and quotations against the recording."]
    return "\n".join(header) + "\n\n" + "\n\n".join(paragraphs) + "\n"


def process_environment(profile: Path, job_dir: Path, options: Options):
    env = os.environ.copy()
    prefix = Path(sys.executable).parent
    env["PATH"] = os.pathsep.join(str(p) for p in
        (prefix, prefix / "Library" / "bin", prefix / "Scripts")) + os.pathsep + env.get("PATH", "")
    env["STUDIO_JOB_DIR"] = str(job_dir)
    env["BUZZ_MODEL_ROOT"] = env.get("TRANSCRIPT_STUDIO_MODEL_ROOT", str(profile / "models"))
    env["BUZZ_FORCE_CPU"] = "true" if options.cpu_only else "false"
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def stop_process_tree(process):
    if process is None or process.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                           capture_output=True, timeout=8, creationflags=subprocess.CREATE_NO_WINDOW)
        except subprocess.TimeoutExpired:
            pass
        if process.poll() is None:
            process.terminate()
    else:
        process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


class JobManager:
    def __init__(self, profile: Path, command_factory=None):
        self.profile = profile.resolve()
        self.profile.mkdir(parents=True, exist_ok=True)
        self.jobs = {}
        self.lock = threading.RLock()
        self.command_factory = command_factory

    def start(self, options: Options):
        with self.lock:
            if any(j["status"] in ("running", "canceling") for j in self.jobs.values()):
                raise ValueError("A transcription is already running. Finish or cancel it first.")
            output = Path(options.output_dir)
            output.mkdir(parents=True, exist_ok=True)
            # Check write access without overwriting an existing output.
            with tempfile.TemporaryFile(dir=output):
                pass
            uid = uuid.uuid4().hex
            job = {"id": uid, "status": "running", "stage": "loading", "progress": None,
                   "message": "Starting the transcription engine", "started": time.time(),
                   "finished": None, "options": asdict(options), "output": None,
                   "logs": deque(maxlen=180), "process": None, "cancel": threading.Event()}
            self.jobs[uid] = job
            threading.Thread(target=self._run, args=(job, options), daemon=True).start()
            return uid

    def _event(self, job, event):
        with self.lock:
            kind = event.get("kind")
            if kind in ("stage", "progress"):
                job["stage"] = event.get("stage", job["stage"])
                value = event.get("fraction")
                job["progress"] = max(0, min(1, float(value))) if value is not None else None
                job["message"] = event.get("message") or {
                    "loading": "Loading the engine / downloading the model if needed",
                    "downloading": "Downloading the hearing audio",
                    "transcribing": "Converting speech to text",
                }.get(job["stage"], "Working")
            elif kind == "segments_ready":
                job.update(stage="saving", progress=None, message="Saving your TXT transcript")
            elif kind == "failure":
                job["backend_error"] = str(event.get("message", "Transcription failed"))

    def _run(self, job, options):
        job_dir = Path(tempfile.mkdtemp(prefix="job_", dir=self.profile))
        log_dir = self.profile / "logs"
        log_dir.mkdir(exist_ok=True)
        log_path = log_dir / f"{job['id']}.log"
        process = None
        try:
            worker = "faster_worker.py" if options.model_type == "fasterwhisper" else "buzz_bridge.py"
            command = [sys.executable, "-u", str(ROOT / worker), "add",
                       "--model-type", options.model_type, "--model-size", options.model_size,
                       "--txt", "--hide-gui", "--output-directory", str(job_dir)]
            if options.language:
                command += ["--language", options.language]
            if options.model_type == "huggingface":
                command += ["--hfid", options.model_id]
            command.append(options.url)
            if self.command_factory:
                command = self.command_factory(job_dir, options)
            with log_path.open("w", encoding="utf-8") as log:
                env = process_environment(self.profile, job_dir, options)
                if job["cancel"].is_set():
                    raise InterruptedError("Canceled")
                process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                with self.lock:
                    job["process"] = process
                if job["cancel"].is_set():
                    stop_process_tree(process)
                for line in process.stdout:
                    log.write(line)
                    log.flush()
                    if line.startswith("STUDIO_EVENT "):
                        try:
                            self._event(job, json.loads(line[len("STUDIO_EVENT "):]))
                        except (ValueError, TypeError):
                            pass
                    else:
                        with self.lock:
                            job["logs"].append(line.rstrip()[-1800:])
                code = process.wait()
            if job["cancel"].is_set():
                raise InterruptedError("Canceled")
            result_path = job_dir / "segments.json"
            if code != 0 or job.get("backend_error") or not result_path.is_file():
                details = job.get("backend_error") or "\n".join(list(job["logs"])[-12:])
                raise RuntimeError(details or f"Engine exited with code {code} without a transcript.")
            payload = json.loads(result_path.read_text(encoding="utf-8"))
            text = render_transcript(payload, options)
            filename = f"Transcript_{options.video_id}_{datetime.now():%Y-%m-%d_%H-%M-%S}_{job['id'][:6]}.txt"
            target = Path(options.output_dir) / filename
            with self.lock:
                if job["cancel"].is_set():
                    raise InterruptedError("Canceled")
                with target.open("x", encoding="utf-8-sig", newline="\n") as out:
                    out.write(text)
                job.update(status="completed", stage="completed", progress=1, output=str(target),
                           message="Your TXT transcript is ready", title=payload.get("title", filename))
        except InterruptedError:
            with self.lock:
                job.update(status="canceled", stage="canceled", message="Canceled. No final transcript was saved.")
        except Exception as exc:
            with self.lock:
                details = str(exc)[-6000:]
                job["logs"].append(details)
                lowered = details.lower()
                message = "The transcription engine could not finish. Expand Technical details for the error, or try again."
                if any(s in lowered for s in ("cuda", "cudnn", "cublas", "gpu")):
                    message = "The GPU could not run this model. Turn on Use CPU only under More options and try again."
                elif any(s in lowered for s in ("403", "429", "sign in", "private video", "unavailable", "http error")):
                    message = "The video could not be downloaded. Check that it is publicly accessible; YouTube may also be limiting downloads. See Technical details."
                elif "no speech" in lowered or "no readable speech" in lowered:
                    message = details
                elif "memory" in lowered:
                    message = "There was not enough memory for this model. Choose a smaller model and try again."
                job.update(status="failed", stage="failed", message=message)
        finally:
            if process:
                stop_process_tree(process)
                if process.stdout:
                    process.stdout.close()
            # Only remove the verified, freshly created per-job directory.
            resolved = job_dir.resolve()
            if resolved.parent == self.profile and resolved.name.startswith("job_"):
                shutil.rmtree(resolved, ignore_errors=True)
            with self.lock:
                job["finished"] = time.time()
                job["process"] = None

    def snapshot(self):
        with self.lock:
            result = []
            for job in sorted(self.jobs.values(), key=lambda j: j["started"], reverse=True):
                public = {key: job[key] for key in ("id", "status", "stage", "progress", "message",
                    "started", "finished", "options", "output")}
                public["logs"] = list(job["logs"])
                result.append(public)
            return result

    def cancel(self, uid):
        with self.lock:
            job = self.jobs.get(uid)
            if not job:
                raise KeyError("Job not found")
            if job["status"] not in ("running", "canceling"):
                return
            job["cancel"].set()
            job.update(status="canceling", message="Stopping the transcription")
            process = job["process"]
        stop_process_tree(process)

    def output_path(self, uid):
        with self.lock:
            job = self.jobs.get(uid)
            if not job or job["status"] != "completed" or not job["output"]:
                raise KeyError("Completed transcript not found")
            return Path(job["output"])

    def close(self):
        for job in self.snapshot():
            if job["status"] in ("running", "canceling"):
                self.cancel(job["id"])
