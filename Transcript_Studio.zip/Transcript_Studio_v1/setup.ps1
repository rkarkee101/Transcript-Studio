param([switch]$NewEnvironment, [switch]$CheckOnly)
. (Join-Path $PSScriptRoot 'common.ps1')

function Download-StudioFile([string]$Url, [string]$Destination) {
    Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing -ErrorAction Stop
}

function Install-BuildTools {
    $existingRoot = Get-BuildToolsRoot
    $sdkRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\Include'
    $sdk = @(Get-ChildItem -Path (Join-Path $sdkRoot '*\um\Windows.h') -File -ErrorAction SilentlyContinue)
    if ($existingRoot -and $sdk.Count -gt 0) { Write-Host 'Microsoft C++ compiler and Windows SDK found.'; return }
    Write-Host 'Installing Microsoft C++ Build Tools. Approve the Windows administrator prompt.'
    $installer = Join-Path $StudioHome 'downloads\vs_buildtools.exe'
    Download-StudioFile 'https://aka.ms/vs/17/release/vs_buildtools.exe' $installer
    $signature = Get-AuthenticodeSignature -LiteralPath $installer
    if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft Corporation') { throw 'The Microsoft installer signature could not be verified. The file was not executed.' }
    $installArgs = '--wait --passive --norestart --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended'
    if ($existingRoot) { $installArgs = 'modify --installPath "' + $existingRoot + '" ' + $installArgs }
    $installProcess = Start-Process -FilePath $installer -ArgumentList $installArgs -Verb RunAs -Wait -PassThru
    if ($installProcess.ExitCode -eq 3010) {
        [DateTime]::UtcNow.ToString('o') | Set-Content -LiteralPath (Join-Path $StudioHome 'restart-required.txt')
        throw [System.OperationCanceledException]::new('RESTART_REQUIRED')
    }
    if ($installProcess.ExitCode -ne 0) { throw "Build Tools installer exited with code $($installProcess.ExitCode)." }
    if (-not (Get-BuildToolsRoot)) { throw 'The installer finished, but the x64/x86 C++ compiler was not found. Rerun SETUP.cmd after restarting Windows.' }
}

function Install-Miniforge {
    Write-Host 'Conda was not found. Downloading Miniforge from conda-forge.'
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/conda-forge/miniforge/releases/latest' -Headers @{'User-Agent'='Transcript-Studio-Setup'}
    $asset = $release.assets | Where-Object { $_.name -match '^Miniforge3-.+-Windows-x86_64\.exe$' } | Select-Object -First 1
    $hashName = if ($asset) { $asset.name + '.sha256' } else { '' }
    $hashAsset = $release.assets | Where-Object { $_.name -eq $hashName } | Select-Object -First 1
    if (-not $asset -or -not $hashAsset) { throw 'Could not find the official Windows x64 Miniforge installer and checksum.' }
    $installer = Join-Path $StudioHome 'downloads\Miniforge3-Windows-x86_64.exe'
    Download-StudioFile $asset.browser_download_url $installer
    Download-StudioFile $hashAsset.browser_download_url ($installer + '.sha256')
    $expected = ((Get-Content -LiteralPath ($installer + '.sha256') -Raw).Trim() -split '\s+')[0]
    if ((Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash -ne $expected) { throw 'Miniforge checksum verification failed. The file was not executed.' }
    $destination = Join-Path $StudioHome 'miniforge3'
    # NSIS requires /D to be last, and the destination is not quoted separately.
    $installArgs = "/InstallationType=JustMe /RegisterPython=0 /AddToPath=0 /S /D=$destination"
    $installProcess = Start-Process -FilePath $installer -ArgumentList $installArgs -WindowStyle Hidden -Wait -PassThru
    if ($installProcess.ExitCode -ne 0) { throw "Miniforge installer exited with code $($installProcess.ExitCode)." }
    $conda = Join-Path $destination 'Scripts\conda.exe'
    if (-not (Test-Path -LiteralPath $conda)) { throw 'Miniforge installation did not create conda.exe.' }
    return $conda
}

function New-StudioShortcut {
    $desktop = [Environment]::GetFolderPath('Desktop')
    if (-not $desktop) { return }
    $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Transcript Studio.lnk'))
    $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $shortcut.Arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $StudioPackage 'launch.ps1') + '"'
    $shortcut.WorkingDirectory = $StudioPackage
    $shortcut.Description = 'Open Transcript Studio on this computer'
    $shortcut.Save()
}

$exitCode = 0
$transcriptStarted = $false
try {
    if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { throw 'This package targets Windows 10/11 on Intel/AMD 64-bit computers.' }
    New-Item -ItemType Directory -Force -Path $StudioHome,(Join-Path $StudioHome 'downloads'),(Join-Path $StudioHome 'logs') | Out-Null
    Start-Transcript -LiteralPath (Join-Path $StudioHome ('logs\setup_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.log')) | Out-Null
    $transcriptStarted = $true
    Write-Host 'Transcript Studio 1.0 - setup' -ForegroundColor Green
    Write-Host 'Uses local speech recognition. The first full installation downloads several GB.'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $marker = Join-Path $StudioHome 'restart-required.txt'
    if (Test-Path -LiteralPath $marker) {
        $recorded = [DateTime]::Parse((Get-Content -LiteralPath $marker -Raw)).ToUniversalTime()
        $boot = Get-StudioBootTime
        if ($boot -le $recorded) { throw [System.OperationCanceledException]::new('RESTART_REQUIRED') }
        Remove-Item -LiteralPath $marker
    }
    $python = Find-BuzzPython
    if ($CheckOnly) {
        if (-not $python) { throw 'A ready Buzz 1.4.5 / Python 3.12 environment was not found.' }
        Set-StudioPythonEnvironment $python
        Invoke-StudioChecked $python @((Join-Path $StudioPackage 'app.py'),'--check')
        Write-Host "Working runtime found: $python"
    } else {
        if ($python -and -not $NewEnvironment) {
            Write-Host "Reusing the existing working Buzz environment: $python"
        } else {
            Install-BuildTools
            $conda = Get-CondaExecutable
            if (-not $conda) { $conda = Install-Miniforge }
            $prefix = Join-Path $StudioHome 'runtime'
            Write-Host 'Creating / repairing a separate Python 3.12 environment.'
            if (Test-Path -LiteralPath (Join-Path $prefix 'conda-meta')) {
                Invoke-StudioChecked $conda @('install','--prefix',$prefix,'--override-channels','-c','conda-forge','python=3.12','pip','ffmpeg','tk','-y')
            } else {
                Invoke-StudioChecked $conda @('create','--prefix',$prefix,'--override-channels','-c','conda-forge','python=3.12','pip','ffmpeg','tk','-y')
            }
            $python = Join-Path $prefix 'python.exe'
            Set-StudioPythonEnvironment $python
            Invoke-StudioChecked $python @('-m','pip','install','--upgrade','pip','setuptools','wheel')
            Invoke-StudioChecked $python @('-m','pip','install','diffq==0.2.4','-c',(Join-Path $StudioPackage 'constraints-validated.txt'))
            Invoke-StudioChecked $python @('-m','pip','install','-r',(Join-Path $StudioPackage 'requirements.txt'),'-c',(Join-Path $StudioPackage 'constraints-validated.txt'))
            Invoke-StudioChecked $python @('-m','pip','check')
        }
        Set-StudioPythonEnvironment $python
        Invoke-StudioChecked $python @((Join-Path $StudioPackage 'app.py'),'--check')
        Save-StudioRuntime $python
        New-StudioShortcut
        Write-Host 'Setup complete. Double-click START.cmd or the Transcript Studio desktop shortcut.' -ForegroundColor Green
    }
} catch [System.OperationCanceledException] {
    if ($_.Exception.Message -eq 'RESTART_REQUIRED') {
        Write-Host 'Build Tools installed successfully. Restart Windows, then rerun SETUP.cmd.' -ForegroundColor Yellow
        $exitCode = 3010
    } else { Write-Host $_.Exception.Message -ForegroundColor Red; $exitCode = 1 }
} catch {
    Write-Host ('Setup stopped: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('Logs: ' + (Join-Path $StudioHome 'logs'))
    $exitCode = 1
} finally {
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
}
exit $exitCode
