@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
set "STUDIO_EXIT=%ERRORLEVEL%"
echo.
if "%STUDIO_EXIT%"=="3010" echo Restart Windows, then double-click SETUP.cmd again to finish.
if not "%STUDIO_EXIT%"=="0" if not "%STUDIO_EXIT%"=="3010" echo Setup stopped. See the error above and the setup log.
pause
exit /b %STUDIO_EXIT%
