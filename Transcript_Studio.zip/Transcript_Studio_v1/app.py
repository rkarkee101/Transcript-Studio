"""Transcript Studio: a loopback-only, token-protected local browser interface."""
from __future__ import annotations

import argparse
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import metadata
import json
import mimetypes
import os
from pathlib import Path
import secrets
import shutil
import sys
import threading
import time
from urllib.parse import urlsplit
import webbrowser

from core import JobManager, LANGUAGES, Options, ROOT, default_output, user_home


def health():
    prefix = Path(sys.executable).parent
    ffmpeg = shutil.which("ffmpeg") or next((str(p) for p in
        (prefix / "Library" / "bin" / "ffmpeg.exe", prefix / "Scripts" / "ffmpeg.exe") if p.is_file()), None)
    try:
        buzz = metadata.version("buzz-captions")
    except metadata.PackageNotFoundError:
        buzz = None
    return {"ready": bool(buzz and ffmpeg and sys.version_info[:2] == (3, 12)),
            "buzz": buzz, "python": sys.version.split()[0], "ffmpeg": bool(ffmpeg)}


class StudioServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, address, profile=None, manager=None, demo=False):
        self.profile = (profile or user_home()).resolve()
        self.profile.mkdir(parents=True, exist_ok=True)
        self.manager = manager or JobManager(self.profile)
        self.token = secrets.token_urlsafe(32)
        self.demo = demo
        super().__init__(address, Handler)
        self.origin = f"http://127.0.0.1:{self.server_port}"


class Handler(BaseHTTPRequestHandler):
    server: StudioServer

    def log_message(self, *args):
        pass

    def _headers(self, code=200, kind="application/json; charset=utf-8", length=0):
        self.send_response(code)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")

    def _json(self, value, code=200):
        data = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self._headers(code, length=len(data))
        self.end_headers()
        self.wfile.write(data)

    def _authenticated(self):
        # Reject DNS rebinding, cross-origin callers, and callers without this launch's token.
        host = self.headers.get("Host", "")
        origin = self.headers.get("Origin")
        return (host == f"127.0.0.1:{self.server.server_port}" and
                origin in (None, self.server.origin) and
                hmac.compare_digest(self.headers.get("X-Studio-Token", ""), self.server.token))

    def do_GET(self):
        path = urlsplit(self.path).path
        if self.headers.get("Host") != f"127.0.0.1:{self.server.server_port}":
            self._json({"error": "Use the local app URL."}, 403)
            return
        if path in ("/", "/style.css", "/ui.js"):
            asset = ROOT / "web" / ({"/": "index.html"}.get(path, path[1:]))
            data = asset.read_bytes()
            kind = {"/": "text/html", "/style.css": "text/css", "/ui.js": "text/javascript"}[path]
            self._headers(kind=kind + "; charset=utf-8", length=len(data))
            self.end_headers()
            self.wfile.write(data)
            return
        if not self._authenticated():
            self._json({"error": "Open the app using START.cmd to reconnect."}, 403)
            return
        if path == "/api/health":
            self._json({**health(), "version": "1.0.0", "demo": self.server.demo})
        elif path == "/api/state":
            self._json({"jobs": self.server.manager.snapshot(), "output_dir": default_output(),
                        "languages": LANGUAGES, "health": health(), "demo": self.server.demo})
        elif path.startswith("/api/download/"):
            try:
                target = self.server.manager.output_path(path.rsplit("/", 1)[-1])
                data = target.read_bytes()
                self._headers(kind="text/plain; charset=utf-8", length=len(data))
                self.send_header("Content-Disposition", f'attachment; filename="{target.name}"')
                self.end_headers()
                self.wfile.write(data)
            except (KeyError, OSError):
                self._json({"error": "Transcript file not found."}, 404)
        else:
            self._json({"error": "Not found"}, 404)

    def do_POST(self):
        if not self._authenticated():
            self._json({"error": "Open the app using START.cmd to reconnect."}, 403)
            return
        try:
            count = int(self.headers.get("Content-Length", "0"))
            if not 0 < count <= 32768:
                raise ValueError("Invalid request size.")
            if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                raise ValueError("JSON request required.")
            body = json.loads(self.rfile.read(count))
            if not isinstance(body, dict):
                raise ValueError("Invalid request.")
            path = urlsplit(self.path).path
            if path == "/api/jobs":
                uid = self.server.manager.start(Options.from_request(body))
                self._json({"id": uid}, 201)
            elif path == "/api/cancel":
                self.server.manager.cancel(body.get("id", ""))
                self._json({"ok": True})
            elif path == "/api/open-transcript":
                target = self.server.manager.output_path(body.get("id", ""))
                if os.name == "nt":
                    os.startfile(str(target))
                self._json({"ok": True})
            elif path == "/api/open-folder":
                folder = Path(body.get("path", "") or default_output())
                if not folder.is_absolute() or not folder.is_dir():
                    raise ValueError("The output folder does not exist yet.")
                if os.name == "nt":
                    os.startfile(str(folder.resolve()))
                self._json({"ok": True})
            elif path == "/api/browse":
                import tkinter as tk
                from tkinter import filedialog
                root = tk.Tk()
                root.withdraw()
                root.attributes("-topmost", True)
                try:
                    chosen = filedialog.askdirectory(title="Choose transcript output folder", parent=root)
                finally:
                    root.destroy()
                self._json({"path": chosen})
            elif path == "/api/shutdown":
                self._json({"ok": True})
                def shutdown():
                    self.server.manager.close()
                    self.server.shutdown()
                threading.Thread(target=shutdown, daemon=True).start()
            else:
                self._json({"error": "Not found"}, 404)
        except (ValueError, TypeError, AttributeError, OSError, KeyError) as exc:
            self._json({"error": str(exc)}, 400)
        except Exception as exc:
            self._json({"error": f"Unable to complete this action: {exc}"}, 500)


def main():
    parser = argparse.ArgumentParser(description="Transcript Studio local app")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        status = health()
        print(json.dumps(status))
        return 0 if status["ready"] else 1
    profile = user_home()
    profile.mkdir(parents=True, exist_ok=True)
    state_file = profile / "server.json"
    # Reuse an existing healthy instance, without starting a second transcription server.
    if state_file.is_file():
        try:
            import urllib.request
            existing = json.loads(state_file.read_text(encoding="utf-8"))
            address = existing["origin"]
            if urlsplit(address).hostname != "127.0.0.1":
                raise ValueError("Not a local server")
            req = urllib.request.Request(address + "/api/health", headers={"X-Studio-Token": existing["token"]})
            with urllib.request.urlopen(req, timeout=2) as response:
                if response.status == 200:
                    url = address + "/#token=" + existing["token"]
                    print(url, flush=True)
                    if not args.no_browser:
                        webbrowser.open(url)
                    return 0
        except Exception:
            pass
    server = StudioServer(("127.0.0.1", args.port), profile=profile)
    state_file.write_text(json.dumps({"origin": server.origin, "token": server.token,
                                     "pid": os.getpid()}), encoding="utf-8")
    url = server.origin + "/#token=" + server.token
    print(url, flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.manager.close()
        server.server_close()
        try:
            if json.loads(state_file.read_text(encoding="utf-8")).get("pid") == os.getpid():
                state_file.unlink()
        except (OSError, ValueError):
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
