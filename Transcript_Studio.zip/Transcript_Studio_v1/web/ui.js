'use strict';
const $ = id => document.getElementById(id);
const fragment = new URLSearchParams(location.hash.slice(1));
const token = fragment.get('token') || sessionStorage.getItem('studioToken') || '';
if (token) sessionStorage.setItem('studioToken', token);
let jobs = [], busy = false, initialized = false, connected = true, lastJob = null;
const formIds = ['url','modelType','modelSize','language','timestamps','spacing','outputDir','cpuOnly','modelId','browse'];

async function api(path, body) {
  const response = await fetch(path, {method: body === undefined ? 'GET':'POST', headers:{'X-Studio-Token':token, ...(body === undefined ? {}:{'Content-Type':'application/json'})}, body:body === undefined ? undefined:JSON.stringify(body)});
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || 'The app could not complete that request.');
  return value;
}
function formError(message) { $('formError').textContent = message; $('formError').hidden = !message; }
function formatElapsed(seconds) {const s=Math.max(0,Math.floor(seconds)), h=Math.floor(s/3600), m=Math.floor(s/60)%60;return (h ? String(h).padStart(2,'0')+':' : '')+String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function syncControls() {
  const hf=$('modelType').value==='huggingface';
  $('hfField').hidden=!hf; $('modelId').required=hf;
  $('modelSize').disabled=busy||hf;
  $('spacingField').hidden=!$('timestamps').checked;
  $('modelHint').textContent=hf?'Choose a public speech recognition model below.':$('modelType').value==='whispercpp'?'Whisper.cpp uses its own model files. The first run may download a new model.':'Small is a useful starting point. Larger models need more time and memory.';
}
function savePreferences(){const data={};for(const id of formIds.filter(i=>i!=='url'&&i!=='browse'))data[id]=$(id).type==='checkbox'?$(id).checked:$(id).value;localStorage.setItem('studioPreferences',JSON.stringify(data));}
function render() {
  const current = jobs[0];
  busy=jobs.some(j=>['running','canceling'].includes(j.status));
  formIds.forEach(id=>$(id).disabled=busy);
  $('start').disabled=busy||!connected;
  $('start').innerHTML=busy?'Transcription in progress <span>◷</span>':'Create transcript <span>↗</span>';
  syncControls();
  $('idleState').hidden=!!current; $('activeState').hidden=!current;
  if(current){
    lastJob=current;
    const labels={loading:'Preparing your transcript',downloading:'Downloading audio',transcribing:'Transcribing',saving:'Saving your transcript',completed:'Your transcript is ready',failed:'Something needs attention',canceled:'Transcription canceled',canceling:'Stopping transcription'};
    $('progressTitle').textContent=labels[current.status==='canceling'?'canceling':current.stage]||'Working';
    $('stageBadge').textContent=current.status==='running'?current.stage.toUpperCase():current.status.toUpperCase();
    $('jobModel').textContent=(current.options.model_type==='fasterwhisper'?'Faster Whisper':current.options.model_type)+' · '+(current.options.model_type==='huggingface'?current.options.model_id:current.options.model_size);
    $('elapsed').textContent=formatElapsed((current.finished||Date.now()/1000)-current.started);
    const indeterminate=current.status==='running'&&current.progress===null;
    $('bar').parentElement.classList.toggle('indeterminate',indeterminate);
    $('bar').style.width=(current.progress===null?0:current.progress*100)+'%';
    $('progressMessage').textContent=current.status==='failed'?'The engine could not finish this transcription.':current.message;
    $('progressDetail').textContent=current.status==='running'?(current.progress!==null?Math.floor(current.progress*100)+'% of '+(current.stage==='downloading'?'audio download':'transcription')+' · Keep this computer awake.':'The first model download can take several minutes. Keep this computer awake.'):(current.status==='completed'?'Saved as a TXT file. Timestamps are measured from the start of the recording.':'');
    $('jobError').hidden=current.status!=='failed'; $('jobError').textContent=current.status==='failed'?current.message:'';
    $('cancel').hidden=!['running','canceling'].includes(current.status); $('cancel').disabled=current.status==='canceling';
    $('openResult').hidden=current.status!=='completed'; $('downloadResult').hidden=current.status!=='completed';
    $('savedPath').textContent=current.output||'';
    $('logs').textContent=current.logs.join('\n');
  }
  const completed=jobs.filter(j=>j.status==='completed');
  $('results').replaceChildren();
  if(!completed.length){const p=document.createElement('p');p.className='empty-results';p.textContent='Your TXT files will be listed here. Saved files remain in your output folder.';$('results').append(p);}
  completed.forEach(job=>{const row=document.createElement('div');row.className='result';const icon=document.createElement('span');icon.className='file-icon';icon.textContent='TXT';const info=document.createElement('div');info.className='result-info';const name=document.createElement('strong');name.textContent=job.output.split(/[\\/]/).pop();name.title=job.output;const meta=document.createElement('small');meta.textContent=new Date(job.started*1000).toLocaleString()+' · '+(job.options.timestamps?'Timestamped':'Plain text');info.append(name,meta);const button=document.createElement('button');button.type='button';button.className='text-button';button.textContent='Open ↗';button.addEventListener('click',()=>api('/api/open-transcript',{id:job.id}).catch(e=>formError(e.message)));row.append(icon,info,button);$('results').append(row);});
}
async function refresh(){
  try{
    const state=await api('/api/state');
    connected=true;$('demo').hidden=!state.demo;
    if(!initialized){
      const languages=[['','Auto-detect'],...Object.entries(state.languages).sort((a,b)=>a[1].localeCompare(b[1]))];
      $('language').replaceChildren(...languages.map(([code,name])=>new Option(name,code)));
      $('language').value='en';$('outputDir').value=state.output_dir;
      try{const saved=JSON.parse(localStorage.getItem('studioPreferences')||'{}');for(const [id,value] of Object.entries(saved)){if(formIds.includes(id)&&id!=='url'&&id!=='browse'){if($(id).type==='checkbox')$(id).checked=!!value;else $(id).value=value;}}}catch{}
      initialized=true;
    }
    jobs=state.jobs;
    $('engineStatus').classList.toggle('bad',!state.health.ready);
    $('engineStatus').replaceChildren();const dot=document.createElement('i');$('engineStatus').append(dot,document.createTextNode(state.health.ready?'Local engine ready':'Setup required'));
    if(!state.health.ready)formError('Run SETUP.cmd to finish installing the transcription engine.');
    render();$('start').disabled=busy||!state.health.ready;
  }catch(error){connected=false;$('engineStatus').textContent='Disconnected';$('engineStatus').classList.add('bad');$('start').disabled=true;formError(error.message+' Reopen START.cmd if the app was closed.');}
}
$('transcribeForm').addEventListener('submit',async event=>{event.preventDefault();formError('');savePreferences();$('start').disabled=true;try{await api('/api/jobs',{url:$('url').value,model_type:$('modelType').value,model_size:$('modelSize').value,language:$('language').value,timestamps:$('timestamps').checked,spacing:Number($('spacing').value),output_dir:$('outputDir').value,cpu_only:$('cpuOnly').checked,model_id:$('modelId').value});await refresh();}catch(error){formError(error.message);$('start').disabled=false;}});
['modelType','timestamps'].forEach(id=>$(id).addEventListener('change',syncControls));
$('browse').addEventListener('click',async()=>{try{const result=await api('/api/browse',{});if(result.path){$('outputDir').value=result.path;savePreferences();}}catch(error){formError(error.message);}});
$('cancel').addEventListener('click',async()=>{if(lastJob){await api('/api/cancel',{id:lastJob.id}).catch(e=>formError(e.message));await refresh();}});
$('openResult').addEventListener('click',()=>lastJob&&api('/api/open-transcript',{id:lastJob.id}).catch(e=>formError(e.message)));
$('openFolder').addEventListener('click',()=>api('/api/open-folder',{path:$('outputDir').value}).catch(e=>formError(e.message)));
$('downloadResult').addEventListener('click',async()=>{if(!lastJob)return;try{const response=await fetch('/api/download/'+lastJob.id,{headers:{'X-Studio-Token':token}});if(!response.ok)throw new Error('Could not read the saved transcript.');const blob=await response.blob();const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=lastJob.output.split(/[\\/]/).pop();a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(error){formError(error.message);}});
$('quit').addEventListener('click',async()=>{if(busy&&!confirm('A transcription is running. Cancel it and close the app?'))return;try{await api('/api/shutdown',{});clearInterval(poll);$('engineStatus').textContent='App closed';$('start').disabled=true;$('progressTitle').textContent='App closed';$('progressMessage').textContent='You can close this tab. Use START.cmd to open Transcript Studio again.';}catch(error){formError(error.message);}});
const poll=setInterval(refresh,1500);refresh();
