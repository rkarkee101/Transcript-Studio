from __future__ import annotations
import dataclasses
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import JobManager, Options, normalize_youtube_url, render_transcript, timestamp
from app import StudioServer

TEST_TEMP = Path(__file__).resolve().parents[2] / 'studio_test_temp'
TEST_TEMP.mkdir(exist_ok=True)


def opts(folder, **changes):
    body={'url':'https://www.youtube.com/watch?v=Ki3oCg3jD3E','output_dir':str(folder),
          'model_type':'fasterwhisper','model_size':'small','language':'en','timestamps':True,'spacing':0}
    body.update(changes)
    return Options.from_request(body)


def wait_job(manager, timeout=10):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        value=manager.snapshot()[0]
        if value['finished']:
            return value
        time.sleep(.04)
    raise AssertionError('Job did not finish')


def fake(mode):
    return lambda folder,options:[sys.executable,str(Path(__file__).with_name('fake_worker.py')),mode]


class FormatTests(unittest.TestCase):
    def test_link_variants(self):
        for url in ['https://youtu.be/Ki3oCg3jD3E?t=1','https://m.youtube.com/watch?v=Ki3oCg3jD3E&list=abc','https://youtube.com/live/Ki3oCg3jD3E','https://youtube.com/shorts/Ki3oCg3jD3E']:
            with self.subTest(url=url):
                self.assertEqual(normalize_youtube_url(url)[1],'Ki3oCg3jD3E')

    def test_reject_untrusted_urls(self):
        for url in ['https://youtube.com.evil.test/watch?v=Ki3oCg3jD3E','file:///C:/private.txt','https://127.0.0.1/watch?v=Ki3oCg3jD3E','https://user@youtube.com/watch?v=Ki3oCg3jD3E','https://youtu.be/bad','https://youtube.com/playlist?list=x','https://youtube.com:8123/watch?v=Ki3oCg3jD3E']:
            with self.subTest(url=url), self.assertRaises(ValueError):
                normalize_youtube_url(url)

    def test_timestamp_over_one_hour(self):
        self.assertEqual(timestamp(8*3600*1000+3*60000+52123),'08:03:52')

    def test_unicode_and_segment_times(self):
        payload={'title':'नेपाल hearing','segments':[{'start_ms':3655000,'end_ms':3659000,'text':'नमस्ते — café.'}]}
        text=render_transcript(payload,opts(Path(tempfile.gettempdir())))
        self.assertIn('[01:00:55] नमस्ते — café.',text)
        self.assertIn('नेपाल hearing',text)

    def test_grouped_timestamps(self):
        payload={'segments':[{'start_ms':x*1000,'end_ms':(x+3)*1000,'text':str(x)} for x in (0,5,10,15,20,25,30,35)]}
        text=render_transcript(payload,opts(Path(tempfile.gettempdir()),spacing=30))
        self.assertIn('[00:00:00] 0 5 10 15 20 25',text)
        self.assertIn('[00:00:30] 30 35',text)

    def test_no_timestamp_export(self):
        payload={'segments':[{'start_ms':1000,'end_ms':3000,'text':'A readable sentence.'}]}
        text=render_transcript(payload,opts(Path(tempfile.gettempdir()),timestamps=False))
        self.assertIn('A readable sentence.',text)
        self.assertNotIn('[00:',text)

    def test_reject_empty_or_invalid_segments(self):
        for segments in ([],[{'start_ms':9,'end_ms':1,'text':'bad'}],[{'start_ms':float('nan'),'end_ms':2,'text':'bad'}],[{'start_ms':1,'end_ms':2,'text':'  '}]):
            with self.subTest(segments=segments), self.assertRaises(ValueError):
                render_transcript({'segments':segments},opts(Path(tempfile.gettempdir())))

    def test_option_validation(self):
        for change in ({'model_type':'shell'},{'language':'bad'},{'timestamps':'yes'},{'spacing':True},{'output_dir':'relative'},{'model_type':'huggingface','model_id':'invalid'}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                opts(Path(tempfile.gettempdir()),**change)


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=TEST_TEMP);self.root=Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()
    def test_success_only_exports_txt(self):
        manager=JobManager(self.root/'profile',fake('success'))
        manager.start(opts(self.root/'out'))
        result=wait_job(manager)
        self.assertEqual(result['status'],'completed')
        self.assertIn('[00:00:32]',Path(result['output']).read_text(encoding='utf-8-sig'))
        self.assertEqual([p.suffix for p in (self.root/'out').iterdir()],['.txt'])
        self.assertFalse(list((self.root/'profile').glob('job_*')))
    def test_exit_zero_without_transcript_is_failure(self):
        manager=JobManager(self.root/'profile',fake('zero-without-output'))
        manager.start(opts(self.root/'out'))
        self.assertEqual(wait_job(manager)['status'],'failed')
        self.assertFalse(list((self.root/'out').iterdir()))
    def test_engine_error_zero_exit_is_failure(self):
        manager=JobManager(self.root/'profile',fake('failure'))
        manager.start(opts(self.root/'out'))
        self.assertEqual(wait_job(manager)['status'],'failed')
    def test_cancel_and_no_concurrent_job(self):
        manager=JobManager(self.root/'profile',fake('wait'))
        uid=manager.start(opts(self.root/'out'))
        with self.assertRaises(ValueError):manager.start(opts(self.root/'out'))
        time.sleep(.15);manager.cancel(uid)
        self.assertEqual(wait_job(manager)['status'],'canceled')
        self.assertFalse(list((self.root/'out').iterdir()))
    def test_second_run_does_not_overwrite(self):
        manager=JobManager(self.root/'profile',fake('success'))
        manager.start(opts(self.root/'out'));first=wait_job(manager)['output']
        manager.start(opts(self.root/'out'));second=wait_job(manager)['output']
        self.assertNotEqual(first,second)
        self.assertEqual(len(list((self.root/'out').glob('*.txt'))),2)


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=TEST_TEMP);self.profile=Path(self.tmp.name)
        self.server=StudioServer(('127.0.0.1',0),profile=self.profile,manager=JobManager(self.profile,fake('success')))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
    def tearDown(self):
        self.server.manager.close();self.server.shutdown();self.server.server_close();self.thread.join();self.tmp.cleanup()
    def request(self,path,body=None,token=True,origin=None):
        headers={'X-Studio-Token':self.server.token} if token else {}
        if origin:headers['Origin']=origin
        if body is not None:headers['Content-Type']='application/json'
        req=urllib.request.Request(self.server.origin+path,data=None if body is None else json.dumps(body).encode(),headers=headers)
        return urllib.request.urlopen(req,timeout=10)
    def test_root_and_state(self):
        with self.request('/') as result:self.assertIn(b'Transcript Studio',result.read())
        with self.request('/api/state') as result:self.assertIn('languages',json.load(result))
    def test_auth_and_cross_origin(self):
        for token,origin in [(False,None),(True,'https://untrusted.example')]:
            with self.subTest(token=token,origin=origin),self.assertRaises(urllib.error.HTTPError) as exc:
                self.request('/api/state',token=token,origin=origin)
            self.assertEqual(exc.exception.code,403)
    def test_bad_url_and_valid_job_download(self):
        with self.assertRaises(urllib.error.HTTPError):self.request('/api/jobs',{'url':'https://example.com'})
        with self.request('/api/jobs',dataclasses.asdict(opts(self.profile/'out'))) as response:uid=json.load(response)['id']
        wait_job(self.server.manager)
        with self.request('/api/download/'+uid) as response:
            self.assertIn(b'Synthetic test recording',response.read());self.assertIn('.txt',response.headers['Content-Disposition'])
    def test_no_arbitrary_file_access(self):
        for path in ['/api/download/../../private','/../core.py','/core.py']:
            with self.subTest(path=path),self.assertRaises(urllib.error.HTTPError):self.request(path)


if __name__=='__main__':unittest.main(verbosity=2)
