"""Synthetic worker for lifecycle tests. Never used by the normal launcher."""
import json
import os
from pathlib import Path
import sys
import time

folder = Path(os.environ['STUDIO_JOB_DIR'])
mode = sys.argv[1] if len(sys.argv) > 1 else 'success'
print('STUDIO_EVENT '+json.dumps({'kind':'progress','stage':'transcribing','fraction':0.4}), flush=True)
if mode == 'wait':
    time.sleep(60)
elif mode == 'failure':
    print('STUDIO_EVENT '+json.dumps({'kind':'failure','message':'Synthetic engine failure'}), flush=True)
elif mode == 'zero-without-output':
    pass
else:
    time.sleep(0.2)
    (folder/'segments.json').write_text(json.dumps({'title':'Synthetic test recording', 'segments':[
        {'start_ms':1000,'end_ms':2500,'text':'This is a synthetic test transcript.'},
        {'start_ms':32000,'end_ms':36000,'text':'It is not testimony from the linked hearing.'}]}),encoding='utf-8')
