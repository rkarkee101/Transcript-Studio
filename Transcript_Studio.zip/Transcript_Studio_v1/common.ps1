Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$StudioPackage = $PSScriptRoot
$StudioHome = if ($env:TRANSCRIPT_STUDIO_HOME) { $env:TRANSCRIPT_STUDIO_HOME } else { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'TranscriptStudio' }

function Set-StudioPythonEnvironment([string]$Python) {
    $prefix = Split-Path -Parent $Python
    $env:PATH = "$prefix;$prefix\Library\mingw-w64\bin;$prefix\Library\usr\bin;$prefix\Library\bin;$prefix\Scripts;" + $env:PATH
    $env:CONDA_PREFIX = $prefix
    $env:PYTHONUTF8 = '1'
    $env:PYTHONIOENCODING = 'utf-8'
}

function Test-BuzzPython([string]$Python) {
    if (-not $Python -or -not (Test-Path -LiteralPath $Python -PathType Leaf)) { return $false }
    $testCode = "import sys,importlib.metadata as m; assert sys.version_info[:2]==(3,12); assert m.version('buzz-captions')=='1.4.5'; m.version('yt-dlp'); m.version('platformdirs')"
    try {
        $null = & $Python -B -c $testCode 2>&1
        if ($LASTEXITCODE -ne 0) { return $false }
        $prefix = Split-Path -Parent $Python
        return ((Test-Path -LiteralPath (Join-Path $prefix 'Library\bin\ffmpeg.exe')) -or [bool](Get-Command ffmpeg -ErrorAction SilentlyContinue))
    } catch { return $false }
}

function Get-CondaExecutable {
    $candidates = @($env:CONDA_EXE)
    $command = Get-Command conda.exe -ErrorAction SilentlyContinue
    if ($command) { $candidates += $command.Source }
    foreach ($root in @((Join-Path $StudioHome 'miniforge3'), (Join-Path $env:USERPROFILE 'miniconda3'), (Join-Path $env:USERPROFILE 'anaconda3'), (Join-Path $env:USERPROFILE 'miniforge3'), (Join-Path $env:USERPROFILE 'Miniforge3'), (Join-Path $env:ProgramData 'miniconda3'), (Join-Path $env:ProgramData 'anaconda3'))) {
        $candidates += Join-Path $root 'Scripts\conda.exe'
    }
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate }
    }
    return $null
}

function Find-BuzzPython {
    $candidates = @()
    $configPath = Join-Path $StudioHome 'runtime.json'
    if (Test-Path -LiteralPath $configPath) {
        try { $config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json; $candidates += $config.python } catch {}
    }
    if ($env:CONDA_PREFIX) { $candidates += Join-Path $env:CONDA_PREFIX 'python.exe' }
    $candidates += Join-Path $StudioHome 'runtime\python.exe'
    foreach ($base in @('miniconda3','anaconda3','miniforge3','Miniforge3')) {
        $candidates += Join-Path $env:USERPROFILE "$base\envs\buzz\python.exe"
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-BuzzPython $candidate) { return $candidate }
    }
    $conda = Get-CondaExecutable
    if ($conda) {
        try {
            $data = (& $conda env list --json 2>$null | Out-String) | ConvertFrom-Json
            foreach ($prefix in $data.envs) {
                $candidate = Join-Path $prefix 'python.exe'
                if (Test-BuzzPython $candidate) { return $candidate }
            }
        } catch {}
    }
    return $null
}

function Save-StudioRuntime([string]$Python) {
    New-Item -ItemType Directory -Force -Path $StudioHome | Out-Null
    @{ python = $Python; buzz_version = '1.4.5'; configured = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $StudioHome 'runtime.json') -Encoding UTF8
}

function Invoke-StudioChecked([string]$File, [string[]]$Arguments) {
    & $File @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Command failed (exit $LASTEXITCODE): $File $($Arguments -join ' ')" }
}

function Get-BuildToolsRoot {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $vswhere)) { return $null }
    $root = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
    if ($LASTEXITCODE -eq 0 -and $root) { return ($root | Select-Object -First 1) }
    return $null
}

function Get-StudioBootTime {
    # Avoid a WMI/CIM dependency for the installer's restart checkpoint.
    if (-not ('TranscriptStudioUptime' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class TranscriptStudioUptime {
    [DllImport("kernel32.dll")]
    public static extern UInt64 GetTickCount64();
}
'@
    }
    return [DateTime]::UtcNow.AddMilliseconds(-[double][TranscriptStudioUptime]::GetTickCount64())
}
