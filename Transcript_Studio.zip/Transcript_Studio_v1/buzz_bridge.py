"""Run Buzz's CLI with isolated settings and report its real segment timings.

Buzz 1.4.5 can quit with exit code zero after a failed task. The wrapper therefore
records success/error signals as well as the exit code. No Buzz source is edited.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys

EVENT_PREFIX = "STUDIO_EVENT "


def emit(kind: str, **fields):
    print(EVENT_PREFIX + json.dumps({"kind": kind, **fields}, ensure_ascii=False), flush=True)


def main():
    job_dir = Path(os.environ["STUDIO_JOB_DIR"]).resolve()
    job_dir.mkdir(parents=True, exist_ok=True)
    profile = job_dir / "backend"
    profile.mkdir(exist_ok=True)
    os.environ["WIN_PD_OVERRIDE_LOCAL_APPDATA"] = str(profile)
    os.environ["WIN_PD_OVERRIDE_APPDATA"] = str(profile)
    os.environ["BUZZ_DISABLE_TELEMETRY"] = "1"
    os.environ["BUZZ_DISABLE_UPDATE_CHECK"] = "true"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    # The CLI constructs Qt widgets even with --hide-gui. Keep all of them offscreen.
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    os.environ["PYTHONIOENCODING"] = "utf-8"
    temp_dir = job_dir / "temp"
    temp_dir.mkdir(exist_ok=True)
    os.environ["TEMP"] = os.environ["TMP"] = str(temp_dir)

    emit("stage", stage="loading", message="Loading the transcription engine / model")
    import platformdirs.windows
    # Also works with platformdirs releases predating WIN_PD_OVERRIDE_*.
    original_folder = platformdirs.windows.get_win_folder

    def private_folder(name):
        if name in ("CSIDL_LOCAL_APPDATA", "CSIDL_APPDATA"):
            return str(profile)
        return original_folder(name)

    platformdirs.windows.get_win_folder = private_folder
    from PyQt6.QtCore import QSettings
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat, QSettings.Scope.UserScope, str(profile / "settings"))

    # Transcript Studio only needs transcription. Do not load optional Buzz
    # plugins, install their extra packages, or run their post-processing hooks.
    from buzz.widgets.main_window import MainWindow
    from buzz.plugins.manager import PluginManager
    PluginManager.initialize = lambda self: None
    original_complete = MainWindow.on_task_completed
    original_error = MainWindow.on_task_error
    original_progress = MainWindow.on_task_progress
    original_download = MainWindow.on_task_download_progress
    failed = []

    def complete(window, task, segments):
        payload = {
            "title": Path(task.file_path).stem,
            "segments": [
                {"start_ms": int(s.start), "end_ms": int(s.end), "text": s.text.strip()}
                for s in segments
            ],
        }
        target = job_dir / "segments.json"
        pending = target.with_suffix(".pending")
        pending.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        pending.replace(target)
        emit("segments_ready", count=len(segments))
        original_complete(window, task, segments)

    def error(window, task, message):
        failed.append(str(message))
        (job_dir / "error.txt").write_text(str(message), encoding="utf-8")
        emit("failure", message=str(message))
        original_error(window, task, message)

    def progress(window, task, fraction):
        emit("progress", stage="transcribing", fraction=max(0, min(1, float(fraction))))
        original_progress(window, task, fraction)

    def download(window, task, fraction):
        emit("progress", stage="downloading", fraction=max(0, min(1, float(fraction))))
        original_download(window, task, fraction)

    MainWindow.on_task_completed = complete
    MainWindow.on_task_error = error
    MainWindow.on_task_progress = progress
    MainWindow.on_task_download_progress = download
    from buzz.buzz import main as buzz_main
    sys.argv = ["buzz", *sys.argv[1:]]
    try:
        buzz_main()
    except SystemExit as exc:
        raise SystemExit(1 if failed else exc.code)


if __name__ == "__main__":
    main()
