. (Join-Path $PSScriptRoot 'common.ps1')
try {
    $python = Find-BuzzPython
    if (-not $python) { throw 'Run SETUP.cmd first to install the transcription engine.' }
    New-Item -ItemType Directory -Force -Path $StudioHome,(Join-Path $StudioHome 'logs') | Out-Null
    Save-StudioRuntime $python
    Set-StudioPythonEnvironment $python
    # Reuse the user's downloaded Buzz models, if present. Each job still has private settings/database.
    $existingModels = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Buzz\Buzz\Cache\models'
    if (-not $env:TRANSCRIPT_STUDIO_MODEL_ROOT -and (Test-Path -LiteralPath $existingModels -PathType Container)) {
        $env:TRANSCRIPT_STUDIO_MODEL_ROOT = $existingModels
    }
    $tag = Get-Date -Format 'yyyyMMdd_HHmmss_ffff'
    $outLog = Join-Path $StudioHome "logs\app_$tag.log"
    $errLog = Join-Path $StudioHome "logs\app_$tag.err.log"
    $app = Join-Path $StudioPackage 'app.py'
    $process = Start-Process -FilePath $python -ArgumentList @('-u',('"' + $app + '"')) -WorkingDirectory $StudioPackage -WindowStyle Hidden -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru
    for ($i = 0; $i -lt 100; $i++) {
        Start-Sleep -Milliseconds 200
        $process.Refresh()
        if ($process.HasExited) {
            if ($process.ExitCode -eq 0) { exit 0 }
            throw ('The app could not start. ' + (Get-Content -LiteralPath $errLog -Raw))
        }
        if ((Test-Path -LiteralPath $outLog) -and (Select-String -LiteralPath $outLog -Pattern 'http://127.0.0.1:' -Quiet)) { exit 0 }
    }
    throw "The app is taking longer than expected to open. Check $errLog"
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
